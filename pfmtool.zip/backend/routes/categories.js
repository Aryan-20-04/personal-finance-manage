const express=require('express');
const router=express.Router();
const auth=require('../middleware/auth');
const Category=require('../models/Category');

router.get('/',auth,async (req,res)=>{
    try{
        const categories=await Category.find({user:req.user.id});
        res.json(categories);
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.post('/',auth,async (req,res)=>{
    try{
        const{name,type}=req.body;
        const category=new Category({
            user:req.user.id,
            name,
            type
        });
        await category.save();
        res.status(201).json(category);
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.put('/:id',auth,async (req,res)=>{
    try{
        const category=await Category.findOneAndUpdate(
            {_id: req.params.id,user:req.user.id},
            req.body,
            {new:true}
        );
        if (!category) return res.status(404).json({message:'Category not found'});
        res.json(category);
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.delete('/:id',auth,async (req,res)=>{
    try{
        const category=await Category.findOneAndDelete({_id: req.params.id,user:req.user.id});
        if (!category) return res.status(404).json({message:'Category not found'});
        res.json({message:'Category deleted'});
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

module.exports=router;