const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Expense = require('../models/Expense');

// Protect these routes
router.post('/', auth, async (req,res)=>{
    try{
        const{title, amount,category,date}=req.body;
        const expense=new Expense({
            user:req.user.id,
            title,
            amount,
            category,
            date,
        });
        await expense.save();
        res.status(201).json(expense);
    }catch(err){
        console.error(err);
        res.status(500).json({message: err.message});
    }
});
router.get('/', auth, async (req, res) => {
  try {
    const { category } = req.query;
    const filter = { user: req.user.id };

    // Add category filter if provided
    if (category) {
      filter.category = category;
    }

    const expenses = await Expense.find(filter).sort({ date: -1 });
    res.json(expenses);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

//Add an expense
router.put('/:id',auth,async (req,res)=>{
    try{
        const expense=await Expense.findOneAndUpdate(
            {_id: req.params.id, user:req.user.id},
            req.body,
            {new:true}
        );
        if (!expense) return res.status(404).json({message:'Expense not found'});
        res.json(expense);
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

//Delete an expense
router.delete('/:id',auth,async(req,res)=>{
    try{
        const expense=await Expense.findOneAndDelete({_id:req.params.id,user:req.user.id});
        if(!expense)return res.status(404).json({message:'Expense not found'});
        res.json({message: 'Expense deleted'});
    }catch(err){
        res.status(500).json({message:err.message});
    }
});
module.exports = router;
