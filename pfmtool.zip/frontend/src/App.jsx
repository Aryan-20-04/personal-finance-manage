import React, { useEffect, useMemo, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import {jwtDecode} from 'jwt-decode'
import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import Expenses from './pages/Expenses';

const App = () => {
  const [themeMode, setThemeMode] = useState('light');

  
  useEffect(()=>{
    const token=localStorage.getItem('token');
    if (token){
      try{
        const decoded=jwtDecode(token);
        const expiry=decoded.exp*1000;
        const now=Date.now();
        if (expiry<now){
          localStorage.removeItem('token');
          window.location.href='./login';
        }else{
          const timeout=expiry-now;
          const timer=setTimeout(()=>{
            alert("Session expired. Logging Out...");
            localStorage.removeItem('token');
            window.location.href='./login';
          },timeout);
          return ()=>clearTimeout(timer);
        }
      }catch(err){
        console.error("Invalid Token:",err);
        localStorage.removeItem('token');
        window.location.href='./login';
      }
    }
  },[]);

  // Create a theme instance based on current theme mode
  const theme = useMemo(() =>
    createTheme({
      palette: {
        mode: themeMode,
        ...(themeMode === 'dark'
          ? {
              background: {
                default: '#121212',
                paper: '#1e1e1e',
              },
              text: {
                primary: '#ffffff',
              },
            }
          : {}),
      },
    }), [themeMode]
  );

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline /> {/* Applies global base styles based on theme */}
      <Router>
        <Navbar themeMode={themeMode} setThemeMode={setThemeMode} />
        <Routes>
          <Route path="/" element={
            <ProtectedRoute>
              <Dashboard themeMode={themeMode} setThemeMode={setThemeMode} />
            </ProtectedRoute>
          } />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/expenses" element={
            <ProtectedRoute>
              <Expenses themeMode={themeMode} setThemeMode={setThemeMode} />
            </ProtectedRoute>
          } />
          <Route path="*" element={<div>404 Not Found</div>} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
};

export default App;
