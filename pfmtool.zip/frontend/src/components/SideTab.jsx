import React from 'react';
import { List, ListItem, ListItemText } from '@mui/material';
import { Link } from 'react-router-dom';

const SideTab = () => (
  <List>
    <ListItem button component={Link} to="/dashboard">
      <ListItemText primary="Dashboard" />
    </ListItem>
    <ListItem button component={Link} to="/expenses">
      <ListItemText primary="Expenses" />
    </ListItem>
  </List>
);

export default SideTab;
