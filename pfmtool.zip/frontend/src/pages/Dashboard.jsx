import React, { useEffect, useState } from 'react';
import {
  Container, Grid, Card, CardContent, Typography,
  Box, Snackbar, Switch, FormControlLabel, TextField,
  CircularProgress, Tooltip as MuiTooltip, LinearProgress,
  List, ListItem, ListItemText, Divider, Alert, Paper,
  AppBar, Toolbar, IconButton, Tooltip
} from '@mui/material';
import {
  PieChart, Pie, Cell, Tooltip as RechartTooltip, Legend, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, CartesianGrid
} from 'recharts';
import {
  TrendingUp, Category, CurrencyRupee,
  LightMode, DarkMode, Menu as MenuIcon, Notifications as NotificationsIcon
} from '@mui/icons-material';
import { motion } from 'framer-motion';
import axios from 'axios';


const COLORS = ['#42a5f5', '#66bb6a', '#ef5350', '#ffa726', '#ab47bc', '#26c6da'];

const Dashboard = ({ themeMode, setThemeMode }) => {
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [budget, setBudget] = useState(() => Number(localStorage.getItem('budget')) || 100000);
  const [showBudgetAlert, setShowBudgetAlert] = useState(false);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');

  const totalAmount = Array.isArray(expenses)
    ? expenses.reduce((acc, curr) => acc + curr.amount, 0)
    : 0;

  const budgetUsage = Math.min((totalAmount / budget) * 100, 100).toFixed(2);

  const categoryData = categories.map(cat => {
    const total = expenses
      .filter(exp => exp.category === cat.name)
      .reduce((acc, curr) => acc + curr.amount, 0);
    return { name: cat.name, value: total };
  });

  const monthlyData = expenses.reduce((acc, curr) => {
    const month = new Date(curr.date).toLocaleString('default', { month: 'short', year: 'numeric' });
    acc[month] = (acc[month] || 0) + curr.amount;
    return acc;
  }, {});
  const trendData = Object.entries(monthlyData).map(([month, value]) => ({ month, value }));

  const recentTransactions = [...expenses]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 5);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [expenseRes, categoryRes] = await Promise.all([
          axios.get('/api/expenses', { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('/api/categories', { headers: { Authorization: `Bearer ${token}` } })
        ]);

        setExpenses(Array.isArray(expenseRes.data) ? expenseRes.data : expenseRes.data.expenses || []);
        setCategories(Array.isArray(categoryRes.data) ? categoryRes.data : categoryRes.data.categories || []);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching dashboard data", err);
        setLoading(false);
      }
    };
    fetchData();
  }, [token]);

  useEffect(() => {
    localStorage.setItem('budget', budget);
  }, [budget]);

  useEffect(() => {
    if (!Array.isArray(expenses)) return;
    const total = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    setShowBudgetAlert(total > budget || total >= 0.9 * budget);
  }, [expenses, budget]);

  const toggleTheme = () => setThemeMode(prev => (prev === 'light' ? 'dark' : 'light'));

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress size={60} thickness={5} />
      </Box>
    );
  }

  return (
    <>
      {/* App Bar */}
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" color="inherit"><MenuIcon /></IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>PFM Tool Dashboard</Typography>
          <Tooltip title="Notifications">
            <IconButton color="inherit"><NotificationsIcon /></IconButton>
          </Tooltip>
          <FormControlLabel
            control={<Switch checked={themeMode === 'dark'} onChange={toggleTheme} />}
            label={themeMode === 'dark' ? <DarkMode /> : <LightMode />}
            sx={{ ml: 2 }}
          />
        </Toolbar>
      </AppBar>

      <Container sx={{ mt: 4, mb: 6 }}>
        {/* Greeting */}
        <Box mb={2}>
          <Typography variant="h4" fontWeight={700}>👋 Hello, User</Typography>
          <Typography variant="subtitle2" color="textSecondary">Welcome back! Here’s your financial overview.</Typography>
        </Box>

        {/* Budget Control */}
        <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={2} mb={3}>
          <Typography variant="subtitle1" fontWeight={500}>
            Budget Usage: ₹{totalAmount.toLocaleString()} / ₹{budget.toLocaleString()} ({budgetUsage}%)
          </Typography>
          <MuiTooltip title="Adjust Monthly Budget">
            <TextField
              label="Budget (₹)"
              variant="outlined"
              size="small"
              value={budget}
              type="number"
              onChange={(e) => setBudget(Number(e.target.value))}
              inputProps={{ min: 0 }}
            />
          </MuiTooltip>
        </Box>
        <LinearProgress
          variant="determinate"
          value={parseFloat(budgetUsage)}
          sx={{
            height: 12,
            borderRadius: 6,
            mb: 4,
            backgroundColor: themeMode === 'dark' ? '#444' : '#e0e0e0',
            '& .MuiLinearProgress-bar': {
              backgroundColor: budgetUsage > 90 ? '#ef5350' : '#42a5f5'
            }
          }}
        />

        {/* Summary Cards */}
        <Grid container spacing={3}>
          {[
            { title: 'Total Expenses', value: expenses.length, icon: <TrendingUp />, color: 'primary' },
            { title: 'Total Categories', value: categories.length, icon: <Category />, color: 'secondary' },
            { title: 'Total Spent', value: `₹${totalAmount.toLocaleString()}`, icon: <CurrencyRupee />, color: 'success' }
          ].map((item, i) => (
            <Grid item xs={12} sm={4} key={i}>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                <Card sx={{
                  p: 2, display: 'flex', alignItems: 'center', gap: 2,
                  backgroundColor: themeMode === 'dark' ? '#2c2c2c' : '#f9f9f9',
                  '&:hover': { boxShadow: 6 }
                }}>
                  {React.cloneElement(item.icon, { color: item.color, fontSize: 'large' })}
                  <Box>
                    <Typography variant="subtitle2" color="textSecondary">{item.title}</Typography>
                    <Typography variant="h6" fontWeight={600}>{item.value}</Typography>
                  </Box>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* Charts */}
        <Box mt={6}>
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" mb={2}>📂 Spending by Category</Typography>
                {categoryData.length > 0 && categoryData.some(d => d.value > 0) ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie data={categoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                        {categoryData.map((_, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Pie>
                      <RechartTooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <Alert severity="info">No category spending data available yet.</Alert>
                )}
              </Paper>
            </Grid>

            <Grid item xs={12} md={6}>
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="h6" mb={2}>📈 Monthly Trend</Typography>
                <Box sx={{width:'100%',height:300,position:'relative'}}>
                  {trendData.length > 0 ? (
  <Box sx={{ width: '100%', height: 300, position: 'relative' }}>
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={trendData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <RechartTooltip />
        <Line type="monotone" dataKey="value" stroke="#42a5f5" strokeWidth={2} />
      </LineChart>
    </ResponsiveContainer>
  </Box>
) : (
  <Alert severity="info">No monthly trend data available yet.</Alert>
)}

                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Box>

        {/* Recent Transactions */}
        <Box mt={6}>
          <Paper elevation={3} sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>🧾 Recent Transactions</Typography>
            {recentTransactions.length === 0 ? (
              <Alert severity="info">No recent transactions available.</Alert>
            ) : (
              <List dense>
                {recentTransactions.map((exp, i) => (
                  <React.Fragment key={i}>
                    <ListItem>
                      <ListItemText
                        primary={`${exp.category} - ₹${exp.amount}`}
                        secondary={new Date(exp.date).toLocaleDateString()}
                      />
                    </ListItem>
                    {i < recentTransactions.length - 1 && <Divider />}
                  </React.Fragment>
                ))}
              </List>
            )}
          </Paper>
        </Box>

        {/* Budget Alert Snackbar */}
        <Snackbar
          open={showBudgetAlert}
          autoHideDuration={6000}
          onClose={() => setShowBudgetAlert(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert
            onClose={() => setShowBudgetAlert(false)}
            severity={totalAmount > budget ? 'error' : 'warning'}
            sx={{ width: '100%' }}
          >
            {totalAmount > budget
              ? 'You have exceeded your monthly budget!'
              : 'You are nearing your monthly budget limit.'}
          </Alert>
        </Snackbar>
      </Container>
    </>
  );
};

export default Dashboard;
