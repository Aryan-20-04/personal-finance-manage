import React, { useState, useEffect } from 'react';
import {
  Box, Button, Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, Typography, Grid, MenuItem, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Paper, Select, InputLabel, FormControl,
  Snackbar, Alert
} from '@mui/material';
import { motion } from 'framer-motion';
import axios from 'axios';
import AddIcon from '@mui/icons-material/Add';

const Expenses = () => {
  const [expenses, setExpenses] = useState([]);
  const defaultCategories = [
    { name: 'Food' },
    { name: 'Travel' },
    { name: 'Utilities' },
    { name: 'Entertainment' },
    { name: 'Shopping' },
    { name: 'Healthcare' },
    { name: 'Education' },
    { name: 'Bills' },
    { name: 'Groceries' },
    { name: 'Other' }
  ];

  const [categories, setCategories] = useState(defaultCategories);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ amount: '', category: '', description: '', date: '' });
  const [customCategory, setCustomCategory] = useState('');
  const [snack, setSnack] = useState({ open: false, message: '', severity: 'success' });
  const [filterCategory, setFilterCategory] = useState('');

  const token = localStorage.getItem('token');

  const fetchExpenses = async () => {
    try {
      const res = await axios.get('/api/expenses', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setExpenses(res.data.expenses || []);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await axios.get('/api/categories', {
        headers: { Authorization: `Bearer ${token}` }
      });

      const apiCategories = res.data.categories || [];
      const combined = [...defaultCategories];

      apiCategories.forEach(apiCat => {
        if (!combined.find(c => c.name.toLowerCase() === apiCat.name.toLowerCase())) {
          combined.push(apiCat);
        }
      });

      setCategories(combined);
    } catch (err) {
      console.error(err);
      setCategories(defaultCategories);
    }
  };

  useEffect(() => {
    fetchExpenses();
    fetchCategories();
  }, []);

  const handleAddExpense = async () => {
    const finalCategory = form.category === 'Other' ? customCategory : form.category;

    if (!form.amount || !finalCategory || !form.date) {
      setSnack({ open: true, message: 'Please fill all required fields.', severity: 'error' });
      return;
    }

    const newExpense = {
      ...form,
      category: finalCategory
    };

    try {
      await axios.post('/api/expenses', newExpense, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (form.category === 'Other' && customCategory) {
        setCategories(prev => [...prev, { name: customCategory }]);
      }

      fetchExpenses();
      setOpen(false);
      setForm({ amount: '', category: '', description: '', date: '' });
      setCustomCategory('');
      setSnack({ open: true, message: 'Expense added successfully!', severity: 'success' });
    } catch (err) {
      console.error(err);
      setSnack({ open: true, message: 'Failed to add expense.', severity: 'error' });
    }
  };

  const filteredExpenses = filterCategory
    ? expenses.filter(exp => exp.category === filterCategory)
    : expenses;

  return (
    <Box p={3}>
      {/* Controls */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3} flexWrap="wrap" gap={2}>
        <Typography variant="h4" fontWeight={600}>💸 Expenses</Typography>
        <Box display="flex" gap={2} flexWrap="wrap">
          <FormControl size="small">
            <InputLabel>Filter</InputLabel>
            <Select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              label="Filter"
              style={{ minWidth: 120 }}
            >
              <MenuItem value="">All</MenuItem>
              {categories.map(cat => (
                <MenuItem key={cat.name} value={cat.name}>{cat.name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => setOpen(true)}
          >
            Add Expense
          </Button>
        </Box>
      </Box>

      {/* Summary Cards */}
      <Grid container spacing={2} mb={4}>
        {[
          { label: 'Total Transactions', value: filteredExpenses.length },
          {
            label: 'Total Spent',
            value: `₹${filteredExpenses.reduce((acc, curr) => acc + curr.amount, 0).toLocaleString()}`
          },
          { label: 'Active Categories', value: [...new Set(filteredExpenses.map(e => e.category))].length }
        ].map((item, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
            >
              <Paper elevation={3} sx={{ p: 2 }}>
                <Typography variant="subtitle2" color="textSecondary">{item.label}</Typography>
                <Typography variant="h6" fontWeight={600}>{item.value}</Typography>
              </Paper>
            </motion.div>
          </Grid>
        ))}
      </Grid>

      {/* Expense Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Amount (₹)</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredExpenses.map((exp, idx) => (
              <motion.tr
                key={exp._id || idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
                style={{ display: 'table-row' }}
              >
                <TableCell>{new Date(exp.date).toLocaleDateString()}</TableCell>
                <TableCell>{exp.category}</TableCell>
                <TableCell>{exp.description}</TableCell>
                <TableCell>{exp.amount.toLocaleString()}</TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Add Expense Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle>Add New Expense</DialogTitle>
        <DialogContent>
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 8 }}
          >
            <TextField
              label="Amount (₹)"
              fullWidth
              type="number"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })}
            />
            <FormControl fullWidth>
              <InputLabel>Category</InputLabel>
              <Select
                value={form.category}
                onChange={(e) => {
                  setForm({ ...form, category: e.target.value });
                  if (e.target.value !== 'Other') {
                    setCustomCategory('');
                  }
                }}
                label="Category"
              >
                {categories.map(cat => (
                  <MenuItem key={cat.name} value={cat.name}>{cat.name}</MenuItem>
                ))}
              </Select>
            </FormControl>

            {form.category === 'Other' && (
              <TextField
                label="Custom Category Name"
                fullWidth
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
              />
            )}

            <TextField
              label="Description"
              fullWidth
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
            <TextField
              label="Date"
              type="date"
              fullWidth
              InputLabelProps={{ shrink: true }}
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
            />
          </motion.div>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)} color="secondary">Cancel</Button>
          <Button onClick={handleAddExpense} variant="contained" color="primary">Add</Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snack.open}
        autoHideDuration={4000}
        onClose={() => setSnack({ ...snack, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={snack.severity} sx={{ width: '100%' }}>
          {snack.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Expenses;
