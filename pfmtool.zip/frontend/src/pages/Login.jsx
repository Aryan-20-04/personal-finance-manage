import React, { useState } from 'react';
import {
  Container, TextField, Button, Typography, Box, Paper,
  CircularProgress, Alert, Grid
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', formData);
      localStorage.setItem('token', res.data.token);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.msg || 'Oops! Something went wrong. 😬');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #e3f2fd 0%, #ffffff 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        py: 6,
      }}
    >
      <Container maxWidth="md">
        <Paper elevation={4} sx={{ borderRadius: 4, overflow: 'hidden' }}>
          <Grid container>
            {/* Image Side */}
            <Grid
              item
              xs={12}
              md={6}
              sx={{
                backgroundImage: 'url(https://source.unsplash.com/600x600/?finance,money)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                minHeight: 400,
              }}
            />

            {/* Form Side */}
            <Grid item xs={12} md={6}>
              <Box sx={{ p: 4 }}>
                <Typography variant="h4" fontWeight={600} gutterBottom>
                  Welcome Back 👋
                </Typography>
                <Typography variant="body1" color="text.secondary" gutterBottom>
                  Log in to manage your expenses and track your finances like a pro! 💸
                </Typography>

                {error && (
                  <Alert severity="error" sx={{ mt: 2 }}>
                    {error}
                  </Alert>
                )}

                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
                  <TextField
                    label="Email Address"
                    name="email"
                    type="email"
                    fullWidth
                    margin="normal"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                  <TextField
                    label="Password"
                    name="password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />

                  <Box sx={{ mt: 3, position: 'relative' }}>
                    <Button
                      variant="contained"
                      color="primary"
                      type="submit"
                      fullWidth
                      size="large"
                      disabled={loading}
                    >
                      {loading ? 'Logging in...' : 'Let’s Go 🚀'}
                    </Button>

                    {loading && (
                      <CircularProgress
                        size={24}
                        sx={{
                          color: 'primary.main',
                          position: 'absolute',
                          top: '50%',
                          left: '50%',
                          mt: '-12px',
                          ml: '-12px',
                        }}
                      />
                    )}
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </Box>
  );
};

export default Login;
