import React, { useState } from 'react';
import {
  Container, TextField, Button, Typography, Box, Paper,
  CircularProgress, Alert, Grid
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await axios.post('http://localhost:5000/api/auth/register', formData);
      alert('🎉 Registration successful!');
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.msg || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #fce4ec 0%, #ffffff 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        py: 6,
      }}
    >
      <Container maxWidth="md">
        <Paper elevation={4} sx={{ borderRadius: 4, overflow: 'hidden' }}>
          <Grid container>
            {/* Image Side */}
            <Grid
              item
              xs={12}
              md={6}
              sx={{
                backgroundImage: 'url(https://source.unsplash.com/600x600/?startup,team)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                minHeight: 400,
              }}
            />

            {/* Form Side */}
            <Grid item xs={12} md={6}>
              <Box sx={{ p: 4 }}>
                <Typography variant="h4" fontWeight={600} gutterBottom>
                  Get Started 🚀
                </Typography>
                <Typography variant="body1" color="text.secondary" gutterBottom>
                  Sign up to start tracking your expenses and take control of your finances! 📊
                </Typography>

                {error && (
                  <Alert severity="error" sx={{ mt: 2 }}>
                    {error}
                  </Alert>
                )}

                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
                  <TextField
                    label="Full Name"
                    name="name"
                    fullWidth
                    margin="normal"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                  <TextField
                    label="Email Address"
                    name="email"
                    type="email"
                    fullWidth
                    margin="normal"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                  <TextField
                    label="Password"
                    name="password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />

                  <Box sx={{ mt: 3, position: 'relative' }}>
                    <Button
                      variant="contained"
                      color="primary"
                      type="submit"
                      fullWidth
                      size="large"
                      disabled={loading}
                    >
                      {loading ? 'Registering...' : 'Create Account ✨'}
                    </Button>

                    {loading && (
                      <CircularProgress
                        size={24}
                        sx={{
                          color: 'primary.main',
                          position: 'absolute',
                          top: '50%',
                          left: '50%',
                          mt: '-12px',
                          ml: '-12px',
                        }}
                      />
                    )}
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </Box>
  );
};

export default Register;
