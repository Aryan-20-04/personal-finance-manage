// src/utils/auth.js
import jwt_decode from 'jwt-decode';

export const getTokenExpiry = (token) => {
  try {
    const decoded = jwt_decode(token);
    return decoded.exp * 1000; // Convert to milliseconds
  } catch (err) {
    return null;
  }
};

export const scheduleAutoLogout = (token, logoutCallback) => {
  const expiryTime = getTokenExpiry(token);
  if (!expiryTime) return;

  const timeLeft = expiryTime - Date.now();

  if (timeLeft <= 0) {
    logoutCallback();
  } else {
    setTimeout(() => {
      logoutCallback();
    }, timeLeft);
  }
};
